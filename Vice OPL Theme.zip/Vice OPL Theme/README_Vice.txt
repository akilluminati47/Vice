Happy Halloween - AKilluminati47 10/30/2023
_____________

FREE THEME FOR OPL 
_____________

ONLY copy the entire thm_Vice folder into your +OPL THM folder

The OGG File that is fully titled outside that thm_ folder is for reference purpose

Background music included properly in sound folder
______________

bgm.ogg

Tested working. Needs nothing but OPL with background music support, enabled..

ONLY tested on grimdoomers opl fork (uploaded 5/27/23)

TURN OFF COVER ART FOR NO STUTTERING
TURN BOOT SOUND OFF FOR UPDATED BOOT SOUND (incorporated to theme music)

For more music from the featured musician go here:

https://music.apple.com/us/artist/the-grey-archives/1644220084